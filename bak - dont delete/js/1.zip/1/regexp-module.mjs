function check(input) {
    const regex = /javascript/i;
    return regex.test(input);
}

export { check };
